class Estudiante:
    def __init__(self, nombre):
        self.nombre = nombre
        self.materias = []

    def agregar_materia(self, materia):
        self.materias.append(materia)


class Materia:
    def __init__(self, nombre):
        self.nombre = nombre
        self.notas = {}

    def agregar_nota(self, estudiante, nota_lab, nota_parcial):
        self.notas[estudiante.nombre] = {"Laboratorio": nota_lab, "Parcial": nota_parcial}

    def mostrar_notas(self):
        print(f"Notas de la materia {self.nombre}")
        for estudiante, notas in self.notas.items():
            print(f"Estudiante: {estudiante}, Notas: {notas}")


# Crear estudiantes
estudiante1 = Estudiante("Juan")
estudiante2 = Estudiante("Maria")

# Crear materias
materia1 = Materia("Programacion I")
materia2 = Materia("Base de datos")

# Agregar materias a estudiantes
estudiante1.agregar_materia(materia1)
estudiante2.agregar_materia(materia2)

# Agregar notas a materias
materia1.agregar_nota(estudiante1, 8.5, 7.0)
materia1.agregar_nota(estudiante2, 9.0, 8.5)

# Mostrar notas de una materia
materia1.mostrar_notas()
