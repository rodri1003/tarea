import random

class Jugador:
    def __init__(self, luchador, poder):
        self.luchador = luchador
        self.poder = poder
        self.vida = 100
    
    def lanzar_golpe(self, jugador_objetivo):
        jugador_objetivo.recibir_golpe(0.3)
    
    def recibir_golpe(self, porcentaje):
        self.vida -= porcentaje * 100
        print(f"{self.luchador} ha recibido un golpe. Vida restante: {self.vida}%")

class Juego:
    def __init__(self):
        self.jugador1 = Jugador("Luchador 1", 1.0)
        self.jugador2 = Jugador("Luchador 2", 1.0)
        
    def jugar(self):
        while self.jugador1.vida > 0 and self.jugador2.vida > 0:
            if random.choice([True, False]):
                jugador_atacante = self.jugador1
                jugador_objetivo = self.jugador2
            else:
                jugador_atacante = self.jugador2
                jugador_objetivo = self.jugador1

            jugador_atacante.lanzar_golpe(jugador_objetivo)

juego = Juego()
juego.jugar()
