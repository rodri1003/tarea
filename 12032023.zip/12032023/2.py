class Categoria:
    def __init__(self, nombre):
        self.nombre = nombre
    
    def __str__(self):
        return f"Categoría: {self.nombre}"
    
class Pelicula(Categoria):
    def __init__(self, nombre, categoria):
        super().__init__(categoria)
        self.nombre = nombre
        
    def __str__(self):
        return f"Película: {self.nombre}, {super().__str__()}"
        
class Cliente:
    def __init__(self):
        self.peliculas = {
            "Acción": Pelicula("Matrix", "Acción"),
            "Comedia": Pelicula("La gran estafa", "Comedia"),
            "Terror": Pelicula("El conjuro", "Terror")
        }
        
    def mostrar_peliculas(self, categoria):
        if categoria in self.peliculas:
            print(f"Películas de {categoria}:")
            print(self.peliculas[categoria])
        else:
            print("No hay películas disponibles para esa categoría.")

cliente = Cliente()
cliente.mostrar_peliculas("Acción")
cliente.mostrar_peliculas("Comedia")
cliente.mostrar_peliculas("Terror")
cliente.mostrar_peliculas("Drama")
